﻿namespace ParcialATIS.Models
{
    public class Auto
    {
        public int IdAuto { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Placa { get; set; }
        public string Tipo { get; set; }
        public string Estado { get; set; }
        public double CostoDia { get; set; }
        public string Imagen { get; set; }
        public string Newimagen { get; set; }
    }
}
