﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using ParcialATIS.Models;
using System;
using SkiaSharp;

namespace ParcialATIS.Controllers
{
    public class FacturasController : Controller
    {
        private readonly DbController _dbController;

        public FacturasController()
        {
            _dbController = new DbController();
        }

        public IActionResult Factura(int idAuto)
        {
            // Obtener el cliente actual desde la sesión
            var clienteId = HttpContext.Session.GetInt32("ClienteId");
            if (clienteId == null)
            {
                return RedirectToAction("Login", "Clientes"); // Redirigir al login si no hay sesión activa
            }

            // Obtener datos del auto
            var auto = new Auto();
            using (var connection = _dbController.GetConnection())
            {
                connection.Open();
                string query = "SELECT * FROM autos WHERE idauto = @IdAuto";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@IdAuto", idAuto);

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        auto = new Auto
                        {
                            IdAuto = idAuto,
                            Marca = reader["marca"].ToString(),
                            Modelo = reader["modelo"].ToString(),
                            Placa = reader["placa"].ToString(),
                            Tipo = reader["tipo"].ToString(),
                            CostoDia = Convert.ToDouble(reader["costodia"]),
                            Imagen = reader["imagen"].ToString()
                        };
                    }
                }
            }

            if (auto == null)
            {
                return NotFound("El auto no existe.");
            }

            var factura = new Factura
            {
                IdAuto = auto.IdAuto,
                Imagen = auto.Imagen,
                Marca = auto.Marca,
                Modelo = auto.Modelo,
                Placa = auto.Placa,
                Tipo = auto.Tipo,
                CostoDia = auto.CostoDia
            };

            return View(factura);
        }

        [HttpPost]
        public IActionResult Guardar(int cantidadDias, int idAuto)
        {
            var clienteId = HttpContext.Session.GetInt32("ClienteId");
            if (clienteId == null)
            {
                return RedirectToAction("Login", "Clientes");
            }

            var factura = new Factura();
            using (var connection = _dbController.GetConnection())
            {
                connection.Open();
                string queryAuto = "SELECT costodia FROM autos WHERE idauto = @IdAuto";
                MySqlCommand cmdAuto = new MySqlCommand(queryAuto, connection);
                cmdAuto.Parameters.AddWithValue("@IdAuto", idAuto);

                using (var reader = cmdAuto.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        factura.CostoDia = Convert.ToDouble(reader["costodia"]);
                    }
                }

                factura.Subtotal = cantidadDias * factura.CostoDia;
                factura.IVA = factura.Subtotal * 0.13;
                factura.Total = factura.Subtotal + factura.IVA;

                string query = @"INSERT INTO facturas (idcliente, idauto, fecha, subtotal, iva, total) 
                         VALUES (@IdCliente, @IdAuto, @Fecha, @Subtotal, @IVA, @Total)";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@IdCliente", clienteId);
                cmd.Parameters.AddWithValue("@IdAuto", idAuto);
                cmd.Parameters.AddWithValue("@Fecha", DateTime.Now);
                cmd.Parameters.AddWithValue("@Subtotal", factura.Subtotal);
                cmd.Parameters.AddWithValue("@IVA", factura.IVA);
                cmd.Parameters.AddWithValue("@Total", factura.Total);

                cmd.ExecuteNonQuery();
            }

            // Generar recibo en PNG
            return GenerarRecibo(factura);
        }

        private IActionResult GenerarRecibo(Factura factura)
        {
            // Definir el tamaño del recibo
            int width = 800;
            int height = 600;

            // Crear un bitmap para renderizar el recibo
            using var bitmap = new SKBitmap(width, height);
            using var canvas = new SKCanvas(bitmap);

            // Establecer el color de fondo
            canvas.Clear(SKColors.White);

            // Definir estilos de texto
            var paintTitle = new SKPaint
            {
                Color = SKColors.Black,
                TextSize = 36,
                IsAntialias = true,
                Typeface = SKTypeface.FromFamilyName("Arial", SKFontStyle.Bold)
            };

            var paintBody = new SKPaint
            {
                Color = SKColors.Black,
                TextSize = 24,
                IsAntialias = true
            };

            var paintGray = new SKPaint
            {
                Color = SKColors.Gray,
                TextSize = 24,
                IsAntialias = true
            };

            // Dibujar encabezado
            canvas.DrawText("Recibo de Facturación", 50, 50, paintTitle);

            // Dibujar datos del auto
            canvas.DrawText($"Auto: {factura.Marca} {factura.Modelo}", 50, 120, paintBody);
            canvas.DrawText($"Placa: {factura.Placa}", 50, 160, paintBody);
            canvas.DrawText($"Tipo: {factura.Tipo}", 50, 200, paintBody);
            canvas.DrawText($"Costo por Día: ${factura.CostoDia:F2}", 50, 240, paintBody);

            // Dibujar datos de la factura
            canvas.DrawText($"Días Rentados: {factura.CantidadDias}", 50, 300, paintBody);
            canvas.DrawText($"Subtotal: ${factura.Subtotal:F2}", 50, 340, paintBody);
            canvas.DrawText($"IVA (13%): ${factura.IVA:F2}", 50, 380, paintBody);
            canvas.DrawText($"Total: ${factura.Total:F2}", 50, 420, paintBody);

            // Dibujar fecha
            canvas.DrawText($"Fecha: {DateTime.Now:dd/MM/yyyy}", 50, 480, paintGray);

            // Dibujar agradecimiento
            canvas.DrawText("¡Gracias por su preferencia!", 50, 540, paintBody);

            // Generar la imagen PNG
            using var image = SKImage.FromBitmap(bitmap);
            using var data = image.Encode(SKEncodedImageFormat.Png, 100);

            // Devolver el archivo como respuesta
            return File(data.ToArray(), "image/png", "ReciboFactura.png");
        }
    }
}
